-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 07, 2021 at 10:18 AM
-- Server version: 5.7.34-log
-- PHP Version: 7.3.28

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `karonban_bn_quiz`
--

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE `answers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `questionId` bigint(20) UNSIGNED NOT NULL,
  `titleEn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `titleBn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rightAnswer` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `answers`
--

INSERT INTO `answers` (`id`, `questionId`, `titleEn`, `titleBn`, `rightAnswer`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, '16th December 1971', '১৬ ডিসেম্বর ১৯৭১', '0', 1, '2021-03-07 08:21:42', '2021-03-07 08:21:42'),
(2, 1, '26th March 1971', '২৬ মার্চ, ১৯৭১ ', '0', 1, '2021-03-07 08:21:42', '2021-03-07 08:21:42'),
(3, 1, ' 02 March 1971', '০২ ই মার্চ, ১৯৭১ ', '1', 1, '2021-03-07 08:21:42', '2021-03-07 08:21:42'),
(4, 1, '10th April 1971', '১০ এপ্রিল, ১৯৭১ ', '0', 1, '2021-03-07 08:21:42', '2021-03-07 08:21:42'),
(5, 1, '7th March 1971 ', '৭ই মার্চ ১৯৭১', '0', 1, '2021-03-07 08:21:42', '2021-03-07 08:21:42'),
(6, 2, 'Sector no 10', ' সেক্টর নং ১০', '1', 1, '2021-03-07 08:23:59', '2021-03-07 08:23:59'),
(7, 2, 'Sector no 1', 'সেক্টর নং ১  ', '0', 1, '2021-03-07 08:23:59', '2021-03-07 08:23:59'),
(8, 2, 'Sector no 9 ', ' সেক্টর নং ৯  ', '0', 1, '2021-03-07 08:23:59', '2021-03-07 08:23:59'),
(9, 2, 'Sector no 8 ', 'সেক্টর নং ৮ ', '0', 1, '2021-03-07 08:23:59', '2021-03-07 08:23:59'),
(10, 2, 'None of the Above', 'কোনটিই নয় ', '0', 1, '2021-03-07 08:23:59', '2021-03-07 08:23:59'),
(11, 3, 'Z Force', 'জেড ফোর্স ', '0', 1, '2021-03-07 08:26:00', '2021-03-07 08:26:00'),
(12, 3, 'Kilo Flight ', ' কিলো ফ্লাইট ', '1', 1, '2021-03-07 08:26:00', '2021-03-07 08:26:00'),
(13, 3, 'No 1 Squadron', 'এক নম্বর স্কোয়াড্রন', '0', 1, '2021-03-07 08:26:00', '2021-03-07 08:26:00'),
(14, 3, 'Sword Arms', 'সোর্ড আর্মস ', '0', 1, '2021-03-07 08:26:00', '2021-03-07 08:26:00'),
(15, 3, 'Sky Bolt ', 'স্কাই বোল্ট ', '0', 1, '2021-03-07 08:26:00', '2021-03-07 08:26:00');

-- --------------------------------------------------------

--
-- Table structure for table `leaderboards`
--

CREATE TABLE `leaderboards` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `participantId` bigint(20) UNSIGNED NOT NULL,
  `quizStartTime` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quizEndTime` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `correctAnswer` int(11) NOT NULL,
  `totalTime` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `finishTime` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `leaderboards`
--

INSERT INTO `leaderboards` (`id`, `participantId`, `quizStartTime`, `quizEndTime`, `correctAnswer`, `totalTime`, `finishTime`, `created_at`, `updated_at`) VALUES
(1, 1, '1970-01-11 15:19:13', '2021-03-15 16:48:13', 1, '135', 36887, '2021-03-15 20:48:16', '2021-03-15 20:48:16'),
(2, 2, '1970-01-11 21:01:14', '2021-03-15 22:29:46', 0, '135', 7996, '2021-03-16 02:29:49', '2021-03-16 02:29:49'),
(3, 6, '1970-01-21 09:20:58', '2021-03-25 10:50:33', 1, '135', 71189, '2021-03-25 14:51:02', '2021-03-25 14:51:02'),
(4, 9, '1970-01-03 15:21:56', '2021-04-26 09:53:25', 2, '135', 18446, '2021-04-26 04:23:24', '2021-04-26 04:23:24'),
(5, 10, '1969-12-16 04:39:28', '2021-05-27 16:15:29', 1, '135', 123604, '2021-05-27 10:45:30', '2021-05-27 10:45:30'),
(6, 11, '1969-12-16 07:38:58', '2021-05-27 19:13:22', 0, '135', 27818, '2021-05-27 13:43:22', '2021-05-27 13:43:22');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2021_02_27_070649_create_quizzes_table', 1),
(3, '2021_02_27_070810_create_questions_table', 1),
(4, '2021_02_27_070920_create_answers_table', 1),
(6, '2021_02_27_072820_create_results_table', 1),
(7, '2021_02_28_100750_create_quiz_starts_table', 2),
(8, '2021_02_27_071028_create_participants_table', 3),
(10, '2021_03_07_061922_create_quiz_submit_answers_table', 4),
(11, '2021_03_07_061531_create_leaderboards_table', 5);

-- --------------------------------------------------------

--
-- Table structure for table `participants`
--

CREATE TABLE `participants` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `avater` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fullName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contactNumber` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `age` tinyint(3) UNSIGNED DEFAULT NULL,
  `gender` enum('male','female','other') COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quizStart` tinyint(1) NOT NULL DEFAULT '0',
  `quizStartTime` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `participants`
--

INSERT INTO `participants` (`id`, `avater`, `fullName`, `email`, `contactNumber`, `address`, `age`, `gender`, `password`, `quizStart`, `quizStartTime`, `status`, `created_at`, `updated_at`) VALUES
(1, 'https://platform-lookaside.fbsbx.com/platform/profilepic/?asid=10215269729095664&height=50&width=50&ext=1618393982&hash=AeTYgbxJW1dUUu8rlSk', 'Shabnam Deeba', 'shabnam_deeba@yahoo.com', '', NULL, NULL, 'male', '$2y$10$Fh2HPr/qpKG5Vvy1Z2EaSelNddKVoYf4HNLy44PUq7LrVPBHhhCxe', 1, '897553053', 1, '2021-03-15 19:53:11', '2021-03-15 20:47:39'),
(2, 'https://lh3.googleusercontent.com/a-/AOh14GhlO1EKnCgeg46JgyjrjChY2-rXFWDv6eAmspgKvw=s96-c', 'Deeba Shabnam', 'shabnamdeeba@gmail.com', '', NULL, NULL, 'male', '$2y$10$bpELNPJqCgA.vfwxVkbNPuBfNo5tG5F7PYa7DvkT8nRqGAO6oJQYm', 1, '918074888', 1, '2021-03-15 20:57:56', '2021-03-16 02:29:42'),
(3, NULL, 'afneen', 'afneen@gmail.com', '01788866828', 'dhaka', 18, 'male', '$2y$10$eeZRbO49IWL1EVb6QDZBf.ZMdMBnpEqjvCsx0sDAf92E3TPtJRntK', 0, '', 1, '2021-03-15 21:24:38', '2021-03-15 21:24:38'),
(4, 'https://lh6.googleusercontent.com/-5JPEH88oGE8/AAAAAAAAAAI/AAAAAAAAAAA/AMZuucnzTzmziPuukTnC940GqeRZMYZYZw/s96-c/photo.jpg', 'Tahmid Ziko', 'tahmidziko@gmail.com', '', NULL, NULL, 'male', '$2y$10$SM/c9Ixia/6lvlVSjmyWH.ng4APvrwuvIknRy0Q9UmWrEkRUJ5CM.', 0, '', 1, '2021-03-15 21:46:55', '2021-03-15 21:46:55'),
(5, NULL, 'Bipasa', 'bipasa@gmail.com', '01980066259', 'Dhaka', 18, 'female', '$2y$10$G1uERLVpTtXjWtPM883..uy55ZfbV17RODWVg6PILOxMD5Qc0BHsi', 0, '', 1, '2021-03-23 17:14:06', '2021-03-23 17:14:06'),
(6, 'https://platform-lookaside.fbsbx.com/platform/profilepic/?asid=5652168458127416&height=50&width=50&ext=1619238106&hash=AeT1YMXA6xyoDn56BYE', 'Maliha Afneen Qayyum', 'maliha.afneen@live.com', '', NULL, NULL, 'male', '$2y$10$rV5.xssdI51Dd3GwLBSY4u3z5QYfGmMsNVh1FKbEKrIdblYYJkqOC', 1, '1740058958', 1, '2021-03-25 14:22:03', '2021-03-25 14:49:49'),
(7, 'https://platform-lookaside.fbsbx.com/platform/profilepic/?asid=3997273186959954&height=50&width=50&ext=1621329809&hash=AeTbaPBSjZQnDrqZvEc', 'Tahmid Ziko', 'tahmidziko@yahoo.com', '', NULL, NULL, 'male', '$2y$10$kzS1nE6yL6j5Z8IJK3ucMeun9ThADI9truv6VYIzTwdjY4x.BZLGe', 0, '', 1, '2021-04-18 09:53:29', '2021-04-18 09:53:29'),
(8, 'https://lh3.googleusercontent.com/a-/AOh14Gj5N87fKNkxhr1IzrIXz05prQ6b82XgsgESeRpb=s96-c', 'Tahmid Ziko', 'ziko.nwu@gmail.com', '', NULL, NULL, 'male', '$2y$10$YMDtfrhWTsnCB.dOgJGVMOymjpFvrWu8cfTKB0NQ02Vbf4EM8L0Wu', 0, '', 1, '2021-04-18 10:58:53', '2021-04-18 10:58:53'),
(9, 'https://lh3.googleusercontent.com/a-/AOh14Gho0mOrjs5xrBzzRkH-jbPFftZdKF7HMXgBEvRkew=s96-c', 'SDeeba EUCCSEC', 'sdeeba.euccsec@gmail.com', '', NULL, NULL, 'male', '$2y$10$h/4R3AbtfjySpFaG6ZI/FenUQDOD9/u74UTj5oKy.cwTyoBMTWir2', 1, '206516547', 1, '2021-04-26 04:22:58', '2021-04-26 04:23:05'),
(10, NULL, 'Nayan', 'maksudurrahmannayan@gmail.com', '01924348800', 'Barishal', 36, 'male', '$2y$10$lHsU4EiYBVA0ASYhdvWl0uEu1xPBrruDlXWpeoZRJykVB9ArB3TV2', 1, '-1387232408', 1, '2021-05-27 10:40:47', '2021-05-27 10:43:26'),
(11, NULL, 'প্রতিভা শারমিন', 'protivanit@gmail.com', '01751568712', 'বরিশাল', 29, 'female', '$2y$10$Qg8hbCHIL5hzSgYeh6MeiepNBIYm4.9HG5bEZ0n0ne/6z6Zs9Qxk.', 1, '-1376462734', 1, '2021-05-27 13:40:05', '2021-05-27 13:42:55'),
(12, 'https://platform-lookaside.fbsbx.com/platform/profilepic/?asid=3608879949222198&height=50&width=50&ext=1625117772&hash=AeQQmVS3HBdGERdRHXc', 'Saik Yasar Utsho', 'yasarutsho@gmail.com', '', NULL, NULL, 'male', '$2y$10$NuJOGQ/hT21SIrXQcZWtku6Zw4/JWRQXgThAZNr9hQCGUantYktQm', 1, '-971847001', 1, '2021-06-01 06:06:14', '2021-06-01 06:06:31'),
(13, 'https://lh3.googleusercontent.com/a/AATXAJz_QhTFA-GEO4FRxSYJjmcvH3gZaXzwwPwfgqmR=s96-c', 'saik yasar', 'yasarutsho7@gmail.com', '', NULL, NULL, 'male', '$2y$10$TSOo75Xn3XyZJTt/i7VOUuMMh8DhnYgVq0aZBBYn67ZISQE2crrYu', 0, '', 1, '2021-06-01 06:06:58', '2021-06-01 06:06:58');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `quizId` bigint(20) UNSIGNED NOT NULL,
  `titleEn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `titleBn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `quizId`, `titleEn`, `titleBn`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'when the national flag of Bangladesh was hoisted?', 'প্রথম কবে বাংলাদেশের পতাকা উত্তোলন করা হয় ?', 1, '2021-03-07 08:21:41', '2021-03-07 08:21:42'),
(2, 2, 'Inland waterways and coastal areas were covered by which sector in 1971', 'একাত্তরের অভ্যন্তরীণ নৌপথ এবং উপকূলীয় অঞ্চলগুলি কোন সেক্টরের আওতায় ছিল', 1, '2021-03-07 08:23:59', '2021-03-07 08:23:59'),
(3, 3, 'what was the name of first unit of the first Air Force formed in 1971', 'একাত্তরে গঠিত প্রথম বিমান বাহিনীর প্রথম ইউনিটের নাম কী ছিল?', 1, '2021-03-07 08:26:00', '2021-03-07 08:26:00');

-- --------------------------------------------------------

--
-- Table structure for table `quizzes`
--

CREATE TABLE `quizzes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `thumbnail` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `titleEn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `titleBn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shortDescriptionEn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shortDescriptionBn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `view` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `duration` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `quizzes`
--

INSERT INTO `quizzes` (`id`, `thumbnail`, `titleEn`, `titleBn`, `shortDescriptionEn`, `shortDescriptionBn`, `view`, `duration`, `status`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Round 1', 'কুইজ ধাপ : ০১', NULL, NULL, 1, 60, 1, '2021-02-27 09:29:06', '2021-03-06 07:16:58'),
(2, NULL, 'Round 2', 'কুইজ ধাপঃ ০২', NULL, NULL, 1, 45, 1, '2021-02-27 09:29:22', '2021-03-06 06:14:00'),
(3, NULL, 'Round 3', 'কুইজ ধাপঃ ০৩', NULL, NULL, 1, 30, 1, '2021-02-27 09:29:35', '2021-03-07 11:51:43');

-- --------------------------------------------------------

--
-- Table structure for table `quiz_starts`
--

CREATE TABLE `quiz_starts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `participantId` bigint(20) UNSIGNED NOT NULL,
  `quizId` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `quiz_submit_answers`
--

CREATE TABLE `quiz_submit_answers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `participantId` bigint(20) UNSIGNED NOT NULL,
  `answerId` bigint(20) UNSIGNED NOT NULL,
  `time` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `quiz_submit_answers`
--

INSERT INTO `quiz_submit_answers` (`id`, `participantId`, `answerId`, `time`, `created_at`, `updated_at`) VALUES
(1, 1, 2, 28940, '2021-03-15 20:48:16', NULL),
(2, 1, 7, 41814, '2021-03-15 20:48:16', NULL),
(3, 1, 12, 27706, '2021-03-15 20:48:16', NULL),
(4, 2, 4, 56914, '2021-03-16 02:29:49', NULL),
(5, 2, 9, 42511, '2021-03-16 02:29:49', NULL),
(6, 2, 14, 27802, '2021-03-16 02:29:49', NULL),
(7, 6, 3, 45414, '2021-03-25 14:51:02', NULL),
(8, 6, 14, 19179, '2021-03-25 14:51:02', NULL),
(9, 9, 3, 49849, '2021-04-26 04:23:24', NULL),
(10, 9, 8, 40211, '2021-04-26 04:23:24', NULL),
(11, 9, 12, 26709, '2021-04-26 04:23:24', NULL),
(12, 10, 3, 14360, '2021-05-27 10:45:30', NULL),
(13, 11, 4, 52885, '2021-05-27 13:43:22', NULL),
(14, 11, 8, 31828, '2021-05-27 13:43:22', NULL),
(15, 11, 11, 23374, '2021-05-27 13:43:22', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `results`
--

CREATE TABLE `results` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `participantId` bigint(20) UNSIGNED NOT NULL,
  `answerId` bigint(20) UNSIGNED NOT NULL,
  `answerDateTime` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `results`
--

INSERT INTO `results` (`id`, `participantId`, `answerId`, `answerDateTime`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2021-02-27 16:32:37', '2021-02-27 10:32:37', '2021-02-27 10:32:37');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `role` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `role`, `status`, `created_at`, `updated_at`) VALUES
(1, 'admin', 1, '2019-04-23 12:15:35', '2019-04-23 06:15:35'),
(2, 'subscriber', 1, '2019-04-23 12:15:35', '2019-04-23 06:15:35'),
(3, 'superadmin', 1, '2019-04-23 12:15:57', '2019-04-23 06:15:57'),
(4, 'registration', 1, '2020-10-29 13:53:59', '2020-10-29 07:53:59');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `role_id` tinyint(3) UNSIGNED NOT NULL,
  `picture` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `full_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `secret_key` char(32) COLLATE utf8_unicode_ci NOT NULL,
  `mobile_number` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `role_id`, `picture`, `full_name`, `username`, `email`, `secret_key`, `mobile_number`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, 'foysal mahmud', 'foysalmahmud', 'foysal.km68@gmail.com', '3028879ab8d5c87dc023049fa5bb5c1a', '01688784568', 1, '2019-04-23 12:15:00', '2019-04-23 06:18:05'),
(2, 1, NULL, 'coconut for life', 'maricobangladesh', 'info@coconutforlife.org', '6ec1283adcd38ae85141c543ba88e236', '123456789', 1, '2019-04-23 12:15:00', '2019-04-23 06:18:05');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `answers`
--
ALTER TABLE `answers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `answers_questionid_foreign` (`questionId`);

--
-- Indexes for table `leaderboards`
--
ALTER TABLE `leaderboards`
  ADD PRIMARY KEY (`id`),
  ADD KEY `leaderboards_participantid_foreign` (`participantId`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `participants`
--
ALTER TABLE `participants`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `questions_quizid_foreign` (`quizId`);

--
-- Indexes for table `quizzes`
--
ALTER TABLE `quizzes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quiz_starts`
--
ALTER TABLE `quiz_starts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quiz_submit_answers`
--
ALTER TABLE `quiz_submit_answers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `quiz_submit_answers_participantid_foreign` (`participantId`);

--
-- Indexes for table `results`
--
ALTER TABLE `results`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `role` (`role`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `mobile_number` (`mobile_number`),
  ADD KEY `role_id` (`role_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `answers`
--
ALTER TABLE `answers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `leaderboards`
--
ALTER TABLE `leaderboards`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `participants`
--
ALTER TABLE `participants`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `quizzes`
--
ALTER TABLE `quizzes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `quiz_starts`
--
ALTER TABLE `quiz_starts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `quiz_submit_answers`
--
ALTER TABLE `quiz_submit_answers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `results`
--
ALTER TABLE `results`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `answers`
--
ALTER TABLE `answers`
  ADD CONSTRAINT `answers_questionid_foreign` FOREIGN KEY (`questionId`) REFERENCES `questions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `leaderboards`
--
ALTER TABLE `leaderboards`
  ADD CONSTRAINT `leaderboards_participantid_foreign` FOREIGN KEY (`participantId`) REFERENCES `participants` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `questions`
--
ALTER TABLE `questions`
  ADD CONSTRAINT `questions_quizid_foreign` FOREIGN KEY (`quizId`) REFERENCES `quizzes` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `quiz_submit_answers`
--
ALTER TABLE `quiz_submit_answers`
  ADD CONSTRAINT `quiz_submit_answers_participantid_foreign` FOREIGN KEY (`participantId`) REFERENCES `participants` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
